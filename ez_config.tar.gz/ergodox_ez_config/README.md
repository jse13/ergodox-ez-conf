# Helpful hints

[Ergodox EZ Configurator Link](https://configure.ergodox-ez.com)

[Teensy Loader CLI Link](https://www.pjrc.com/teensy/loader_cli.html)

Access keymap for a layout file by going to `configure.ergodox-ez.com/keyboard_layouts/HEX_HASH`
  - HEX_HASH is the 6 character string at the end of the hex file's name.

Command for flashing with the Teensy CLI tool `teensy-loader-cli -v -mmcu=atmega32u4 whatever.hex`